package iuh.fit.se.nhom10.view;

import iuh.fit.se.nhom10.model.TaiKhoanNhanVien;
import iuh.fit.se.nhom10.model.PhongChieu;
import iuh.fit.se.nhom10.model.LoaiPhong;
import iuh.fit.se.nhom10.model.GheNgoi;
import iuh.fit.se.nhom10.service.PhongChieuService;
import iuh.fit.se.nhom10.util.ColorPalette;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Panel quản lý phòng chiếu
 */
public class FrmQuanLyPhongChieuPanel extends JPanel {
    private TaiKhoanNhanVien admin;
    private PhongChieuService service;
    private JTabbedPane tabbedPane;
    private JTable tblPhongChieu, tblLoaiPhong, tblGheNgoi;
    private DefaultTableModel modelPhong, modelLoaiPhong, modelGhe;

    public FrmQuanLyPhongChieuPanel(TaiKhoanNhanVien admin) {
        this.admin = admin;
        this.service = new PhongChieuService();
        setupUI();
    }

    private void setupUI() {
        setLayout(new BorderLayout(10, 10));
        setBackground(ColorPalette.BACKGROUND_CONTENT);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        // Tabbedpane chứa 3 tab: Loại Phòng, Phòng Chiếu, Ghế Ngồi
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(ColorPalette.getFont(ColorPalette.FONT_SIZE_LABEL, Font.BOLD));
        
        tabbedPane.addTab("Loại Phòng", createLoaiPhongTab());
        tabbedPane.addTab("Phòng Chiếu", createPhongChieuTab());
        tabbedPane.addTab("Ghế Ngồi", createGheNgoiTab());

        add(tabbedPane, BorderLayout.CENTER);
    }

    // ===== TAB LOẠI PHÒNG =====
    
    private JPanel createLoaiPhongTab() {
        JPanel pnl = new JPanel(new BorderLayout(10, 10));
        pnl.setBackground(ColorPalette.BACKGROUND_CONTENT);
        pnl.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Panel điều khiển
        JPanel pnlControl = createControlPanel("Loại Phòng", "Thêm Loại", e -> addLoaiPhong());
        pnl.add(pnlControl, BorderLayout.NORTH);

        // Bảng loại phòng
        String[] columnsLoaiPhong = {"Mã Loại Phòng", "Tên Loại Phòng"};
        modelLoaiPhong = new DefaultTableModel(columnsLoaiPhong, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblLoaiPhong = createTable(modelLoaiPhong);
        JScrollPane scrollPane = new JScrollPane(tblLoaiPhong);
        pnl.add(scrollPane, BorderLayout.CENTER);

        // Panel nút
        JPanel pnlButtons = createButtonPanel("Sửa Loại Phòng", "Xóa Loại Phòng",
            e -> editLoaiPhong(), e -> deleteLoaiPhong());
        pnl.add(pnlButtons, BorderLayout.SOUTH);

        loadLoaiPhongData();
        return pnl;
    }

    private void loadLoaiPhongData() {
        modelLoaiPhong.setRowCount(0);
        try {
            List<LoaiPhong> list = service.getAllLoaiPhong();
            for (LoaiPhong lp : list) {
                modelLoaiPhong.addRow(new Object[]{lp.getMaLoaiPhong(), lp.getTenLoaiPhong()});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi tải dữ liệu: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addLoaiPhong() {
        String tenLoaiPhong = JOptionPane.showInputDialog(this, "Nhập tên loại phòng:", "Thêm Loại Phòng", JOptionPane.PLAIN_MESSAGE);
        if (tenLoaiPhong != null && !tenLoaiPhong.trim().isEmpty()) {
            try {
                if (service.addLoaiPhong(tenLoaiPhong)) {
                    JOptionPane.showMessageDialog(this, "Thêm loại phòng thành công", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    loadLoaiPhongData();
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm loại phòng thất bại", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void editLoaiPhong() {
        int row = tblLoaiPhong.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn loại phòng cần sửa", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int maLoaiPhong = (int) modelLoaiPhong.getValueAt(row, 0);
        String tenLoaiPhong = (String) modelLoaiPhong.getValueAt(row, 1);
        String newTen = JOptionPane.showInputDialog(this, "Nhập tên loại phòng mới:", tenLoaiPhong);
        
        if (newTen != null && !newTen.trim().isEmpty()) {
            try {
                if (service.updateLoaiPhong(maLoaiPhong, newTen)) {
                    JOptionPane.showMessageDialog(this, "Cập nhật loại phòng thành công", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    loadLoaiPhongData();
                } else {
                    JOptionPane.showMessageDialog(this, "Cập nhật loại phòng thất bại", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteLoaiPhong() {
        int row = tblLoaiPhong.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn loại phòng cần xóa", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int maLoaiPhong = (int) modelLoaiPhong.getValueAt(row, 0);
        int result = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa loại phòng này?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        
        if (result == JOptionPane.YES_OPTION) {
            try {
                if (service.deleteLoaiPhong(maLoaiPhong)) {
                    JOptionPane.showMessageDialog(this, "Xóa loại phòng thành công", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    loadLoaiPhongData();
                } else {
                    JOptionPane.showMessageDialog(this, "Xóa loại phòng thất bại", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Lỗi xóa: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ===== TAB PHÒNG CHIẾU =====
    
    private JPanel createPhongChieuTab() {
        JPanel pnl = new JPanel(new BorderLayout(10, 10));
        pnl.setBackground(ColorPalette.BACKGROUND_CONTENT);
        pnl.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Panel điều khiển
        JPanel pnlControl = createControlPanel("Phòng Chiếu", "Thêm Phòng", e -> addPhongChieu());
        pnl.add(pnlControl, BorderLayout.NORTH);

        // Bảng phòng chiếu
        String[] columnsPhong = {"Mã Phòng", "Tên Phòng", "Số Ghế", "Loại Phòng"};
        modelPhong = new DefaultTableModel(columnsPhong, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblPhongChieu = createTable(modelPhong);
        JScrollPane scrollPane = new JScrollPane(tblPhongChieu);
        pnl.add(scrollPane, BorderLayout.CENTER);

        // Panel nút
        JPanel pnlButtons = createButtonPanel("Sửa Phòng", "Xóa Phòng",
            e -> editPhongChieu(), e -> deletePhongChieu());
        pnl.add(pnlButtons, BorderLayout.SOUTH);

        loadPhongChieuData();
        return pnl;
    }

    private void loadPhongChieuData() {
        modelPhong.setRowCount(0);
        try {
            List<PhongChieu> list = service.getAllPhongChieu();
            for (PhongChieu p : list) {
                LoaiPhong lp = service.getLoaiPhongByMa(p.getMaLoaiPhong());
                String tenLoaiPhong = (lp != null) ? lp.getTenLoaiPhong() : "N/A";
                modelPhong.addRow(new Object[]{p.getMaPhong(), p.getTenPhong(), p.getSoGhe(), tenLoaiPhong});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi tải dữ liệu: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addPhongChieu() {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Thêm Phòng Chiếu", true);
        dialog.setSize(400, 250);
        dialog.setLocationRelativeTo(this);

        JPanel pnl = new JPanel(new GridLayout(4, 2, 10, 10));
        pnl.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblMaPhong = new JLabel("Mã Phòng:");
        JTextField txtMaPhong = new JTextField();

        JLabel lblTenPhong = new JLabel("Tên Phòng:");
        JTextField txtTenPhong = new JTextField();

        JLabel lblSoGhe = new JLabel("Số Ghế:");
        JTextField txtSoGhe = new JTextField();

        JLabel lblLoaiPhong = new JLabel("Loại Phòng:");
        JComboBox<LoaiPhong> cboLoaiPhong = new JComboBox<>();
        try {
            List<LoaiPhong> loaiPhongs = service.getAllLoaiPhong();
            for (LoaiPhong lp : loaiPhongs) {
                cboLoaiPhong.addItem(lp);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi tải loại phòng: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }

        pnl.add(lblMaPhong);
        pnl.add(txtMaPhong);
        pnl.add(lblTenPhong);
        pnl.add(txtTenPhong);
        pnl.add(lblSoGhe);
        pnl.add(txtSoGhe);
        pnl.add(lblLoaiPhong);
        pnl.add(cboLoaiPhong);

        int option = JOptionPane.showConfirmDialog(this, pnl, "Thêm Phòng Chiếu", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                String maPhong = txtMaPhong.getText().trim();
                String tenPhong = txtTenPhong.getText().trim();
                
                if (maPhong.isEmpty() || tenPhong.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Vui lòng điền đầy đủ thông tin", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                int soGhe = Integer.parseInt(txtSoGhe.getText().trim());
                if (soGhe <= 0) {
                    JOptionPane.showMessageDialog(this, "Số ghế phải lớn hơn 0", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                LoaiPhong loaiPhong = (LoaiPhong) cboLoaiPhong.getSelectedItem();
                if (loaiPhong == null) {
                    JOptionPane.showMessageDialog(this, "Vui lòng chọn loại phòng", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                if (service.addPhongChieu(maPhong, tenPhong, soGhe, loaiPhong.getMaLoaiPhong())) {
                    JOptionPane.showMessageDialog(this, "Thêm phòng chiếu thành công", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    loadPhongChieuData();
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm phòng chiếu thất bại", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Số ghế phải là số nguyên", "Lỗi", JOptionPane.ERROR_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void editPhongChieu() {
        int row = tblPhongChieu.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng cần sửa", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String maPhong = (String) modelPhong.getValueAt(row, 0);
            PhongChieu phong = service.getPhongByMa(maPhong);
            if (phong == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy phòng", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            JPanel pnl = new JPanel(new GridLayout(4, 2, 10, 10));
            pnl.setBorder(new EmptyBorder(15, 15, 15, 15));

            JLabel lblTenPhong = new JLabel("Tên Phòng:");
            JTextField txtTenPhong = new JTextField(phong.getTenPhong());

            JLabel lblSoGhe = new JLabel("Số Ghế:");
            JTextField txtSoGhe = new JTextField(String.valueOf(phong.getSoGhe()));

            JLabel lblLoaiPhong = new JLabel("Loại Phòng:");
            JComboBox<LoaiPhong> cboLoaiPhong = new JComboBox<>();
            List<LoaiPhong> loaiPhongs = service.getAllLoaiPhong();
            for (LoaiPhong lp : loaiPhongs) {
                cboLoaiPhong.addItem(lp);
                if (lp.getMaLoaiPhong() == phong.getMaLoaiPhong()) {
                    cboLoaiPhong.setSelectedItem(lp);
                }
            }

            pnl.add(new JLabel("Mã Phòng:"));
            pnl.add(new JLabel(maPhong));
            pnl.add(lblTenPhong);
            pnl.add(txtTenPhong);
            pnl.add(lblSoGhe);
            pnl.add(txtSoGhe);
            pnl.add(lblLoaiPhong);
            pnl.add(cboLoaiPhong);

            int option = JOptionPane.showConfirmDialog(this, pnl, "Sửa Phòng Chiếu", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                String tenPhong = txtTenPhong.getText().trim();
                if (tenPhong.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Tên phòng không được trống", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                int soGhe = Integer.parseInt(txtSoGhe.getText().trim());
                if (soGhe <= 0) {
                    JOptionPane.showMessageDialog(this, "Số ghế phải lớn hơn 0", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                LoaiPhong loaiPhong = (LoaiPhong) cboLoaiPhong.getSelectedItem();

                if (service.updatePhongChieu(maPhong, tenPhong, soGhe, loaiPhong.getMaLoaiPhong())) {
                    JOptionPane.showMessageDialog(this, "Cập nhật phòng chiếu thành công", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    loadPhongChieuData();
                } else {
                    JOptionPane.showMessageDialog(this, "Cập nhật phòng chiếu thất bại", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Số ghế phải là số nguyên", "Lỗi", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deletePhongChieu() {
        int row = tblPhongChieu.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng cần xóa", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String maPhong = (String) modelPhong.getValueAt(row, 0);
        int result = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa phòng chiếu này?", "Xác nhận", JOptionPane.YES_NO_OPTION);

        if (result == JOptionPane.YES_OPTION) {
            try {
                if (service.deletePhongChieu(maPhong)) {
                    JOptionPane.showMessageDialog(this, "Xóa phòng chiếu thành công", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    loadPhongChieuData();
                } else {
                    JOptionPane.showMessageDialog(this, "Xóa phòng chiếu thất bại", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Lỗi xóa: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ===== TAB GHẾ NGỒI =====
    
    private JPanel createGheNgoiTab() {
        JPanel pnl = new JPanel(new BorderLayout(10, 10));
        pnl.setBackground(ColorPalette.BACKGROUND_CONTENT);
        pnl.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Panel điều khiển
        JPanel pnlControl = createControlPanel("Ghế Ngồi", "Thêm Ghế", e -> addGheNgoi());
        pnl.add(pnlControl, BorderLayout.NORTH);

        // Bảng ghế ngồi
        String[] columnsGhe = {"Mã Ghế", "Hàng", "Cột", "Trạng Thái"};
        modelGhe = new DefaultTableModel(columnsGhe, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblGheNgoi = createTable(modelGhe);
        JScrollPane scrollPane = new JScrollPane(tblGheNgoi);
        pnl.add(scrollPane, BorderLayout.CENTER);

        // Panel nút
        JPanel pnlButtons = createButtonPanel("Sửa Ghế", "Xóa Ghế",
            e -> editGheNgoi(), e -> deleteGheNgoi());
        pnl.add(pnlButtons, BorderLayout.SOUTH);

        loadGheNgoiData();
        return pnl;
    }

    private void loadGheNgoiData() {
        modelGhe.setRowCount(0);
        try {
            List<GheNgoi> list = service.getAllGheNgoi();
            for (GheNgoi g : list) {
                modelGhe.addRow(new Object[]{g.getMaGhe(), g.getHang(), g.getCot(), g.getTrangThai()});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi tải dữ liệu: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addGheNgoi() {
        JPanel pnl = new JPanel(new GridLayout(4, 2, 10, 10));
        pnl.setBorder(new EmptyBorder(15, 15, 15, 15));

        JTextField txtMaGhe = new JTextField();
        JTextField txtHang = new JTextField();
        JTextField txtCot = new JTextField();
        JComboBox<String> cbTrangThai = new JComboBox<>(new String[]{"Trống", "Đã bán", "Khóa"});

        pnl.add(new JLabel("Mã Ghế:"));
        pnl.add(txtMaGhe);
        pnl.add(new JLabel("Hàng:"));
        pnl.add(txtHang);
        pnl.add(new JLabel("Cột:"));
        pnl.add(txtCot);
        pnl.add(new JLabel("Trạng Thái:"));
        pnl.add(cbTrangThai);

        int option = JOptionPane.showConfirmDialog(this, pnl, "Thêm Ghế Ngồi", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                String maGhe = txtMaGhe.getText().trim();
                String hang = txtHang.getText().trim();
                
                if (maGhe.isEmpty() || hang.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Vui lòng điền đầy đủ thông tin", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                int cot = Integer.parseInt(txtCot.getText().trim());
                if (cot <= 0) {
                    JOptionPane.showMessageDialog(this, "Cột phải lớn hơn 0", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                String trangThai = (String) cbTrangThai.getSelectedItem();

                if (service.addGheNgoi(maGhe, hang, cot, trangThai)) {
                    JOptionPane.showMessageDialog(this, "Thêm ghế thành công", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    loadGheNgoiData();
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm ghế thất bại", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Cột phải là số nguyên", "Lỗi", JOptionPane.ERROR_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void editGheNgoi() {
        int row = tblGheNgoi.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn ghế cần sửa", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String maGhe = (String) modelGhe.getValueAt(row, 0);
            GheNgoi ghe = service.getGheByMa(maGhe);
            if (ghe == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy ghế", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            JPanel pnl = new JPanel(new GridLayout(4, 2, 10, 10));
            pnl.setBorder(new EmptyBorder(15, 15, 15, 15));

            JTextField txtHang = new JTextField(ghe.getHang());
            JTextField txtCot = new JTextField(String.valueOf(ghe.getCot()));
            JComboBox<String> cbTrangThai = new JComboBox<>(new String[]{"Trống", "Đã bán", "Khóa"});
            cbTrangThai.setSelectedItem(ghe.getTrangThai());

            pnl.add(new JLabel("Mã Ghế:"));
            pnl.add(new JLabel(maGhe));
            pnl.add(new JLabel("Hàng:"));
            pnl.add(txtHang);
            pnl.add(new JLabel("Cột:"));
            pnl.add(txtCot);
            pnl.add(new JLabel("Trạng Thái:"));
            pnl.add(cbTrangThai);

            int option = JOptionPane.showConfirmDialog(this, pnl, "Sửa Ghế Ngồi", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                String hang = txtHang.getText().trim();
                if (hang.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Hàng không được trống", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                int cot = Integer.parseInt(txtCot.getText().trim());
                if (cot <= 0) {
                    JOptionPane.showMessageDialog(this, "Cột phải lớn hơn 0", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                String trangThai = (String) cbTrangThai.getSelectedItem();

                if (service.updateGheNgoi(maGhe, hang, cot, trangThai)) {
                    JOptionPane.showMessageDialog(this, "Cập nhật ghế thành công", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    loadGheNgoiData();
                } else {
                    JOptionPane.showMessageDialog(this, "Cập nhật ghế thất bại", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Cột phải là số nguyên", "Lỗi", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteGheNgoi() {
        int row = tblGheNgoi.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn ghế cần xóa", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String maGhe = (String) modelGhe.getValueAt(row, 0);
        int result = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa ghế này?", "Xác nhận", JOptionPane.YES_NO_OPTION);

        if (result == JOptionPane.YES_OPTION) {
            try {
                if (service.deleteGheNgoi(maGhe)) {
                    JOptionPane.showMessageDialog(this, "Xóa ghế thành công", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                    loadGheNgoiData();
                } else {
                    JOptionPane.showMessageDialog(this, "Xóa ghế thất bại", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Lỗi xóa: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ===== HELPER METHODS =====
    
    private JPanel createControlPanel(String title, String buttonText, javax.swing.AbstractAction action) {
        JPanel pnl = new JPanel();
        pnl.setLayout(new BorderLayout());
        pnl.setBackground(ColorPalette.BACKGROUND_CONTENT);

        JLabel lbl = new JLabel(title);
        lbl.setFont(ColorPalette.getFont(ColorPalette.FONT_SIZE_SUBTITLE, Font.BOLD));
        lbl.setForeground(ColorPalette.TEXT_LABEL);

        JButton btn = new JButton(buttonText);
        btn.setFont(ColorPalette.getFont(ColorPalette.FONT_SIZE_LABEL, Font.BOLD));
        btn.setBackground(ColorPalette.BUTTON_PRIMARY_BG);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setContentAreaFilled(true);
        btn.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setAction(action);

        pnl.add(lbl, BorderLayout.WEST);
        pnl.add(btn, BorderLayout.EAST);

        return pnl;
    }

    private JPanel createButtonPanel(String btn1Text, String btn2Text, javax.swing.AbstractAction action1, javax.swing.AbstractAction action2) {
        JPanel pnl = new JPanel();
        pnl.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        pnl.setBackground(ColorPalette.BACKGROUND_CONTENT);

        JButton btn1 = new JButton(btn1Text);
        btn1.setFont(ColorPalette.getFont(ColorPalette.FONT_SIZE_LABEL, Font.BOLD));
        btn1.setBackground(ColorPalette.BUTTON_SECONDARY_BG);
        btn1.setForeground(Color.WHITE);
        btn1.setFocusPainted(false);
        btn1.setOpaque(true);
        btn1.setContentAreaFilled(true);
        btn1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn1.setAction(action1);

        JButton btn2 = new JButton(btn2Text);
        btn2.setFont(ColorPalette.getFont(ColorPalette.FONT_SIZE_LABEL, Font.BOLD));
        btn2.setBackground(ColorPalette.BUTTON_DANGER_BG);
        btn2.setForeground(Color.WHITE);
        btn2.setFocusPainted(false);
        btn2.setOpaque(true);
        btn2.setContentAreaFilled(true);
        btn2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn2.setAction(action2);

        pnl.add(btn1);
        pnl.add(btn2);

        return pnl;
    }

    private JTable createTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setFont(ColorPalette.getFont(ColorPalette.FONT_SIZE_LABEL, Font.PLAIN));
        table.getTableHeader().setFont(ColorPalette.getFont(ColorPalette.FONT_SIZE_LABEL, Font.BOLD));
        table.getTableHeader().setBackground(ColorPalette.BUTTON_PRIMARY_BG);
        table.getTableHeader().setForeground(Color.WHITE);
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(100, 149, 237));
        table.setSelectionForeground(Color.WHITE);
        return table;
    }
}
